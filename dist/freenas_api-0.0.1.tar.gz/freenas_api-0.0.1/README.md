# FreeNASAPI Wrapper

This is a simple wrapper for the freenas api.